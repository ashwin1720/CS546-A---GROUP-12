const authorsData = require('./authors');

const customersData = require('./customers');
module.exports = {
    authors: authorsData,
    customers: customersData
};